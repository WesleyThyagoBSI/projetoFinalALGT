import pygame
import sys

WIDTH = 640
HEIGHT = 480
FPS = 30

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ranking")
clock = pygame.time.Clock()


class Person:

    def __init__(self, name, score):
        self.name = name
        self.score = score


def show_ranking(ranking):
    screen.fill(BLACK)
    font = pygame.font.Font(None, 36)
    title_text = font.render("Ranking", True, WHITE)
    screen.blit(title_text, (WIDTH / 2 - title_text.get_width() / 2, 30))

    font = pygame.font.Font(None, 24)
    for i, person in enumerate(ranking):
        person_text = font.render(f"{i+1}. {person.name}: {person.score}",
                                  True, WHITE)
        screen.blit(person_text,
                    (WIDTH / 2 - person_text.get_width() / 2, 80 + i * 30))

    pygame.display.flip()


def main():
    ranking = []

    for i in range(6):
        name = input(f"Digite o nome da pessoa {i+1}: ")
        score = int(input(f"Digite a pontuação da pessoa {i+1}: "))
        person = Person(name, score)
        ranking.append(person)

    ranking.sort(key=lambda x: x.score, reverse=True)

    show_ranking(ranking)

    while True:
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()


if __name__ == '__main__':
    main()
