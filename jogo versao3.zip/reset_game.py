def reset_game():
    global board, current_player, game_over
    board = [" " for _ in range(9)]
    current_player = "X"
    game_over = False

def print_board():
    print("-------------")
    print("|", board[0], "|", board[1], "|", board[2], "|")
    print("-------------")
    print("|", board[3], "|", board[4], "|", board[5], "|")
    print("-------------")
    print("|", board[6], "|", board[7], "|", board[8], "|")
    print("-------------")

def check_winner():
    global game_over
    # Verificando as linhas
    for i in range(0, 9, 3):
        if board[i] == board[i+1] == board[i+2] != " ":
            game_over = True
            return True

    # Verificando as colunas
    for i in range(3):
        if board[i] == board[i+3] == board[i+6] != " ":
            game_over = True
            return True

    # Verificando as diagonais
    if board[0] == board[4] == board[8] != " " or board[2] == board[4] == board[6] != " ":
        game_over = True
        return True

    # Verificando empate
    if " " not in board:
        game_over = True
        return True

    return False

def play_game():
    print("Bem-vindo ao Jogo da Velha!")
    print("Jogador 1: X | Jogador 2: O")
    print_board()

    while not game_over:
        if current_player == "X":
            position = int(input("Jogador 1 (X), escolha uma posição (1-9): "))
        else:
            position = int(input("Jogador 2 (O), escolha uma posição (1-9): "))

        if position < 1 or position > 9:
            print("Posição inválida. Escolha uma posição entre 1 e 9.")
            continue

        if board[position - 1] != " ":
            print("Posição ocupada. Escolha outra posição.")
            continue

        board[position - 1] = current_player
        print_board()

        if check_winner():
            if " " not in board:
                print("Empate!")
            else:
                print("Jogador", current_player, "venceu!")

            choice = input("Deseja jogar novamente? (S/N): ")
            if choice.upper() == "S":
                reset_game()
                print("\nNova partida iniciada.")
                print_board()
            else:
                break

        current_player = "O" if current_player == "X" else "X"

play_game()
