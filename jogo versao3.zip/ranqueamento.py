import pygame
import sys

# Configurações da tela
WIDTH = 640
HEIGHT = 480
FPS = 30

# Cores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Inicialização do Pygame
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ranking")
clock = pygame.time.Clock()

# Classe para representar cada pessoa no ranking
class Person:
    def __init__(self, name, score):
        self.name = name
        self.score = score

# Função para exibir o ranking
def show_ranking(ranking):
    screen.fill(BLACK)
    font = pygame.font.Font(None, 36)
    title_text = font.render("Ranking", True, WHITE)
    screen.blit(title_text, (WIDTH/2 - title_text.get_width()/2, 30))

    font = pygame.font.Font(None, 24)
    for i, person in enumerate(ranking):
        person_text = font.render(f"{i+1}. {person.name}: {person.score}", True, WHITE)
        screen.blit(person_text, (WIDTH/2 - person_text.get_width()/2, 80 + i*30))

    pygame.display.flip()

# Função principal do programa
def main():
    ranking = []

    # Coletando as pontuações
    for i in range(6):
        name = input(f"Digite o nome da pessoa {i+1}: ")
        score = int(input(f"Digite a pontuação da pessoa {i+1}: "))
        person = Person(name, score)
        ranking.append(person)

    # Ordenando o ranking pelo score em ordem decrescente
    ranking.sort(key=lambda x: x.score, reverse=True)

    # Exibindo o ranking
    show_ranking(ranking)

    # Loop principal do jogo
    while True:
        clock.tick(FPS)

        # Verificando eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

if __name__ == '__main__':
    main()
