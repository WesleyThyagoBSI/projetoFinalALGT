import pygame
import sys

pygame.init()

WINDOW_WIDTH = 640
WINDOW_HEIGHT = 480

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
FONT_SIZE = 25

window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Sistema de Rank - Jogo da Velha")

names = []
scores = []

for i in range(4):
    name = input("Digite o nome do jogador {}: ".format(i+1))
    score = int(input("Digite a pontuação do jogador {}: ".format(i+1)))
    names.append(name)
    scores.append(score)

sorted_scores, sorted_names = zip(*sorted(zip(scores, names), reverse=True))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()

    window.fill(BLACK)

    font = pygame.font.Font(None, FONT_SIZE)
    title = font.render("Sistema de Rank", True, WHITE)
    title_rect = title.get_rect(center=(WINDOW_WIDTH/2, 50))
    window.blit(title, title_rect)

    for i, (name, score) in enumerate(zip(sorted_names, sorted_scores)):
        rank = font.render("{}º: {}".format(i+1, name), True, WHITE)
        rank_rect = rank.get_rect(center=(WINDOW_WIDTH/2, 100 + i*FONT_SIZE*2))
        window.blit(rank, rank_rect)

        score_text = font.render("Pontuação: {}".format(score), True, WHITE)
        score_rect = score_text.get_rect(center=(WINDOW_WIDTH/2, 100 + i*FONT_SIZE*2 + FONT_SIZE))
        window.blit(score_text, score_rect)

    pygame.display.update()
