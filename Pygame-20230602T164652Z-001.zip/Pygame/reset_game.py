import tkinter as tk
from tkinter import messagebox

def reset():
    result = messagebox.askyesno("Reset", "Tem certeza que deseja resetar?")
    if result == True:
        # Coloque aqui o código para realizar o reset
        messagebox.showinfo("Reset", "Reset realizado com sucesso!")
    else:
        messagebox.showinfo("Reset", "Reset cancelado!")

# Cria a janela principal
window = tk.Tk()

# Cria um botão para acionar o reset
reset_button = tk.Button(window, text="Reset", command=reset)
reset_button.pack()

# Inicia o loop principal da janela
window.mainloop()