
# importando as bibliotecas
import pygame
import tkinter as tk
from pygame.locals import *
from sys import exit

pygame.init() #inicializando o pygmae

largura = 640
altura = 480

# Variáveis de controle de cadastro
jogador1_registrado = False
jogador2_registrado = False

# Variáveis de pontuação
score = {"jogador_1": 0, "jogador_2": 0}
fonte = pygame.font.SysFont('arial', 15, True, False)

 # criando a tela do jogo
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption('Jogo da Velha')
numero_jogada = 0

pygame.mixer.music.set_volume(0.1)
musica_de_fundo = pygame.mixer.music.load('musica_fundo.mp3')
pygame.mixer.music.play(-1)

clique = pygame.mixer.Sound('smw_coin.wav')

titulo = pygame.image.load('titulo.jpg').convert()
titulo = pygame.transform.scale(titulo, (largura, 40))
image_fundo = pygame.image.load('fundo.jpg').convert()
image_fundo = pygame.transform.scale(image_fundo, (largura, altura))
grade_jogadas = [
    [0,0,0],
    [0,0,0],
    [0,0,0]
]

#FUNCAO PRA RESETAR O JOGO
def reset_jogo():
    print("Teste de reset")

# funções que calculam o score
def update_score(winner):
    global score

    if winner == "jogador_1":
        score["jogador_1"] += 1
    elif winner == "jogador_2":
        score["jogador_2"] += 1

def render_score(screen):
    global fonte
    score_jogador1 = f"Pontos: {score['jogador_1']}"
    score_jogador2 = f"Pontos: {score['jogador_2']}"
    
    # Preencher a área da pontuação com a cor de fundo
    screen.fill((0, 0, 0), (330, 120, 200, 50))
    screen.fill((0, 0, 0), (490, 120, 200, 50))
    
    textJogador1 = fonte.render(score_jogador1, True, (255, 0, 0))
    textJogador2 = fonte.render(score_jogador2, True, (0, 0, 255))
    screen.blit(textJogador1, (330, 120))
    screen.blit(textJogador2, (490, 120))
# ============================

# Função que salva o nome do jogador
def registrar_jogador(name1, name2, janela):
    global jogador1_registrado, jogador2_registrado

    if name1 and name2:
        # Salva o nome do jogador em um arquivo ou banco de dados, por exemplo
        id_jogador1 = f"{name1}"
        id_jogador2 = f"{name2}"
        exibir_jogador1 = fonte.render(id_jogador1, True, (255,0,0))
        exibir_jogador2 = fonte.render(id_jogador2, True, (0,0,255))
        image_fundo.blit(exibir_jogador1, (370, 70))
        image_fundo.blit(exibir_jogador2, (510, 70))


        jogador1_registrado = True
        jogador2_registrado = True

        # Fecha a janela de cadastro
        janela.destroy()
    else:
        # Exibe uma mensagem de erro se algum jogador não for cadastrado
        error_label = tk.Label(janela, text="Ambos os jogadores devem ser cadastrados!")
        error_label.pack()

# Função que exibe a janela de cadastro
def show_register_window():
    # Cria uma janela do tkinter
    register_window = tk.Tk()
    register_window.title("Cadastro de Jogadores")

    # Cria um campo de texto para o nome do jogador 1
    jogador_nome_etiqueta_1 = tk.Label(register_window, text="Nome do Jogador 1:")
    jogador_nome_etiqueta_1.pack()
    jogador_nome_entrada_1 = tk.Entry(register_window)
    jogador_nome_entrada_1.pack()

    # Cria um campo de texto para o nome do jogador 2
    jogador_nome_etiqueta_2 = tk.Label(register_window, text="Nome do Jogador 2:")
    jogador_nome_etiqueta_2.pack()
    jogador_nome_entrada_2 = tk.Entry(register_window)
    jogador_nome_entrada_2.pack()

    # Cria um botão para enviar o cadastro
    register_button = tk.Button(register_window, text="Cadastrar",
                                command=lambda: registrar_jogador(name1=jogador_nome_entrada_1.get(), name2=jogador_nome_entrada_2.get(), janela=register_window))
    register_button.pack()

    register_window.mainloop()

def calcula_jogadas(campo1, campo2, campo3):
    mult = campo1*campo2*campo3
    return mult

def posicao_mouse(numero_jogada):

    posicao_mouse = pygame.mouse.get_pos()
    
    if ((posicao_mouse[0]>10 and posicao_mouse[0]<110) and (posicao_mouse[1]>50 and posicao_mouse[1]<150)): #defininco o primeiro quadrante
        if (grade_jogadas[0][0] == 0):
            if (numero_jogada % 2 != 0):
                grade_jogadas[0][0] = 1
                pygame.draw.circle(image_fundo, (255,0,0), (60, 100), 15)
                clique.play()
            else:
                grade_jogadas[0][0] = 2
                pygame.draw.rect(image_fundo, (0,0,255), (45, 85, 30, 30))
                clique.play()
    elif ((posicao_mouse[0]>110 and posicao_mouse[0]<210) and (posicao_mouse[1]>50 and posicao_mouse[1]<150)):
        if (grade_jogadas[0][1] == 0):
            if (numero_jogada % 2 != 0):
                grade_jogadas[0][1] = 1
                pygame.draw.circle(image_fundo, (255,0,0), (160, 100), 15)
                clique.play()
            else:
                grade_jogadas[0][1] = 2
                pygame.draw.rect(image_fundo, (0,0,255), (145, 85, 30, 30)) 
                clique.play()
    elif ((posicao_mouse[0]>210 and posicao_mouse[0]<310) and (posicao_mouse[1]>50 and posicao_mouse[1]<150)):
        if (grade_jogadas[0][2] == 0):
            if (numero_jogada % 2 != 0):
                grade_jogadas[0][2] = 1
                pygame.draw.circle(image_fundo, (255,0,0), (260, 100), 15)
                clique.play()
            else:
                grade_jogadas[0][2] = 2
                pygame.draw.rect(image_fundo, (0,0,255), (245, 85, 30, 30))  
                clique.play()
    elif ((posicao_mouse[0]>10 and posicao_mouse[0]<110) and (posicao_mouse[1]>150 and posicao_mouse[1]<250)): #defininco o primeiro quadrante
        if (grade_jogadas[1][0] == 0):
            if (numero_jogada % 2 != 0):
                grade_jogadas[1][0] = 1
                pygame.draw.circle(image_fundo, (255,0,0), (60, 200), 15)
                clique.play()
            else:
                grade_jogadas[1][0] = 2
                pygame.draw.rect(image_fundo, (0,0,255), (45, 185, 30, 30))
                clique.play()
    elif ((posicao_mouse[0]>110 and posicao_mouse[0]<210) and (posicao_mouse[1]>=150 and posicao_mouse[1]<=250)):
        if (grade_jogadas[1][1] == 0):
            if (numero_jogada % 2 != 0):
                grade_jogadas[1][1] = 1
                pygame.draw.circle(image_fundo, (255,0,0), (160, 200), 15)
                clique.play()
            else:
                grade_jogadas[1][1] = 2
                pygame.draw.rect(image_fundo, (0,0,255), (145, 185, 30, 30))
                clique.play()
    elif ((posicao_mouse[0]>210 and posicao_mouse[0]<310) and (posicao_mouse[1]>=150 and posicao_mouse[1]<=250)):
        if (grade_jogadas[1][2] == 0):
            if (numero_jogada % 2 != 0):
                grade_jogadas[1][2] = 1
                pygame.draw.circle(image_fundo, (255,0,0), (260, 200), 15)
                clique.play()
            else:
                grade_jogadas[1][2] = 2
                pygame.draw.rect(image_fundo, (0,0,255), (245, 185, 30, 30))
                clique.play()
    elif ((posicao_mouse[0]>10 and posicao_mouse[0]<110) and (posicao_mouse[1]>250 and posicao_mouse[1]<350)): #defininco o primeiro quadrante
        if (grade_jogadas[2][0] == 0):
            if (numero_jogada % 2 != 0):
                grade_jogadas[2][0] = 1
                pygame.draw.circle(image_fundo, (255,0,0), (60, 300), 15)
                clique.play()
            else:
                grade_jogadas[2][0] = 2
                pygame.draw.rect(image_fundo, (0,0,255), (45, 285, 30, 30))
                clique.play()
    elif ((posicao_mouse[0]>110 and posicao_mouse[0]<210) and (posicao_mouse[1]>=250 and posicao_mouse[1]<=350)):
        if (grade_jogadas[2][1] == 0):
            if (numero_jogada % 2 != 0):
                grade_jogadas[2][1] = 1
                pygame.draw.circle(image_fundo, (255,0,0), (160, 300), 15)
                clique.play()
            else:
                grade_jogadas[2][1] = 2
                pygame.draw.rect(image_fundo, (0,0,255), (145, 285, 30, 30))
                clique.play()
    elif ((posicao_mouse[0]>210 and posicao_mouse[0]<310) and (posicao_mouse[1]>=250 and posicao_mouse[1]<=350)):
        if (grade_jogadas[2][2] == 0):
            if (numero_jogada % 2 != 0):
                grade_jogadas[2][2] = 1
                pygame.draw.circle(image_fundo, (255,0,0), (260, 300), 15)
                clique.play()
            else:
                grade_jogadas[2][2] = 2
                pygame.draw.rect(image_fundo, (0,0,255), (245, 285, 30, 30))
                clique.play()

# Loop principal do jogo
while not (jogador1_registrado and jogador2_registrado):
    show_register_window()

if (jogador1_registrado and jogador2_registrado):
    Jogador1Ganhou = False
    Jogador2Ganhou = False
    while True:
        render_score(image_fundo)


        pygame.draw.circle(image_fundo, (255,0,0), (350, 70), 10)
        pygame.draw.rect(image_fundo, (0,0,255), (480, 60, 20, 20))
        tela.blit(image_fundo, (0,0))
        tela.blit(titulo, (0,0))
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                posicao_mouse(numero_jogada)
                numero_jogada += 1
                
                # verifica as jogadas horizontais
                horizontal_1 = grade_jogadas[0][0]*grade_jogadas[0][1]*grade_jogadas[0][2]
                horizontal_2 = grade_jogadas[1][0]*grade_jogadas[1][1]*grade_jogadas[1][2]
                horizontal_3 = grade_jogadas[2][0]*grade_jogadas[2][1]*grade_jogadas[2][2]  

                # verifica as jogadas verticais
                vertical_1 = grade_jogadas[0][0]*grade_jogadas[1][0]*grade_jogadas[2][0]
                vertical_2 = grade_jogadas[0][1]*grade_jogadas[1][1]*grade_jogadas[2][1]
                vertical_3 = grade_jogadas[0][2]*grade_jogadas[1][2]*grade_jogadas[2][2]
                
                # verifica as jogadas diagonais
                diagonal_1 = grade_jogadas[0][0]*grade_jogadas[1][1]*grade_jogadas[2][2]
                diagonal_2 = grade_jogadas[0][2]*grade_jogadas[1][1]*grade_jogadas[2][0]

                possibilidades_ganhador = [
                    horizontal_1,
                    horizontal_2, 
                    horizontal_3,
                    vertical_1, 
                    vertical_2,
                    vertical_3,
                    diagonal_1,
                    diagonal_2
                ]
                iterador = 0
                for j in possibilidades_ganhador:
                    if j == 1:
                        # print("Jogador 1 (BOLA) ganhou!!! ")
                        Jogador1Ganhou = True
                        if (iterador == 0): #horizontal_1
                            pygame.draw.line(image_fundo, (255,0,0), (10, 100), (310, 100))
                        elif (iterador == 1): #horizontal_2
                            pygame.draw.line(image_fundo, (255,0,0), (10, 200), (310, 200))
                        elif (iterador == 2): #horizontal_3
                            pygame.draw.line(image_fundo, (255,0,0), (10, 300), (310, 300))
                        elif (iterador == 3): #vertical_1
                            pygame.draw.line(image_fundo, (255,0,0), (60, 50), (60, 350))
                        elif (iterador == 4): #vertical_2
                            pygame.draw.line(image_fundo, (255,0,0), (160, 50), (160, 350))
                        elif (iterador == 5): #vertical_3
                            pygame.draw.line(image_fundo, (255,0,0), (260, 50), (260, 350))
                        elif (iterador == 6): #diagonal_1
                            pygame.draw.line(image_fundo, (255,0,0), (60, 100), (260, 350))
                        elif (iterador == 7): #diagonal_2
                            pygame.draw.line(image_fundo, (255,0,0), (260, 60), (60, 350))
                        update_score('jogador_1')
                        reset_jogo()
                        sprite_red = []
                        # sprite_red.append('piskel_red/sprite_0.png')
                        # sprite_red.append('piskel_red/sprite_1.png')
                    elif j == 8:
                        # print("Jogador 2 (QUADRADO) ganhou!!!")
                        Jogador2Ganhou = True
                        if (iterador == 0): #horizontal_1
                            pygame.draw.line(image_fundo, (0,0,255), (10, 100), (310, 100))
                        elif (iterador == 1): #horizontal_2
                            pygame.draw.line(image_fundo, (0,0,255), (10, 200), (310, 200))
                        elif (iterador == 2): #horizontal_3
                            pygame.draw.line(image_fundo, (0,0,255), (10, 300), (310, 300))
                        elif (iterador == 3): #vertical_1
                            pygame.draw.line(image_fundo, (0,0,255), (60, 50), (60, 350))
                        elif (iterador == 4): #vertical_2
                            pygame.draw.line(image_fundo, (0,0,255), (160, 50), (160, 350))
                        elif (iterador == 5): #vertical_3
                            pygame.draw.line(image_fundo, (0,0,255), (260, 50), (260, 350))
                        elif (iterador == 6): #diagonal_1
                            pygame.draw.line(image_fundo, (0,0,255), (60, 100), (260, 350))
                        elif (iterador == 7): #diagonal_2
                            pygame.draw.line(image_fundo, (0,0,255), (260, 60), (60, 350))
                        sprite_blue = []
                        update_score('jogador_2')
                        reset_jogo()
                        # sprite_blue.append('piskel_blue/sprite_0.png')
                        # sprite_blue.append('piskel_blue/sprite_1.png')
                    iterador += 1
                
                if (jogador1_registrado == False and jogador2_registrado == False):
                    print("NINGUEM GANHOU!!!!")
                    reset_jogo()
                
                print(f"Numero da jogada: {numero_jogada}")
                print("\n\nGrade de jogadas \n")
                print(grade_jogadas)


        # definindo cor e largura da linha
        cor_da_linha = (255, 255, 255)  # vermelho
        largura_linha = 2


        # desenhando um quadrado sem preenchimento
        square_rect = pygame.Rect(10, 50, 300, 300)
        # desenhando um quadrado sem preenchimento
        score_rect = pygame.Rect(320, 50, 300, 50)
        pygame.draw.rect(tela, cor_da_linha, square_rect, largura_linha)
        pygame.draw.rect(tela, cor_da_linha, score_rect, largura_linha)
        # traçando as linhas verticais da grade 3x3
        pygame.draw.line(tela, (255,255,255), (110, 50), (110, 350))
        pygame.draw.line(tela, (255,255,255), (210, 50), (210, 350))
        pygame.draw.line(tela, (255,255,255), (470, 50), (470, 150))
        # traçando as linhas horizontais da grade 3x3
        pygame.draw.line(tela, (255,255,255), (10, 150), (310, 150))
        pygame.draw.line(tela, (255,255,255), (10, 250), (310, 250))
        # pygame.draw.line(tela, (255,0,0), (210, 50), (210, 350))
        pygame.display.update()
























